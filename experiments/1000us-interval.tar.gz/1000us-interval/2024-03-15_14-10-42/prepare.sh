cat ./raw/*.csv > received.csv
